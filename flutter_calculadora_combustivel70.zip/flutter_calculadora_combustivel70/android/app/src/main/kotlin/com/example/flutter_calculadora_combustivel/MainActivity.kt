package com.example.flutter_calculadora_combustivel

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
